function [X1 E1 k] = RTCDLNU(UU,M,Omega,dim,opts)
%%

if ~exist('opts', 'var')
    opts = [];
end 
if isfield(opts, 'stepsize');    stepsize = opts.stepsize;    end
if isfield(opts, 'patchsize');   patchsize = opts.patchsize;  end
if isfield(opts, 'alpha2');       alpha2 = opts.alpha2;          end
if isfield(opts, 'beta2');        beta2 = opts.beta2;            end
if isfield(opts, 'lambda2');      lambda2 = opts.lambda2;        end
if isfield(opts, 'gamma2');       gamma2 = opts.gamma2;          end

if isfield(opts, 'rho1');        rho1 = opts.rho1;            end
if isfield(opts, 'rho2');        rho2 = opts.rho2;            end
if isfield(opts, 'rho4');        rho4 = opts.rho4;            end

if isfield(opts, 'tau');         tau = opts.tau;        end
if isfield(opts, 'MaxIte');      MaxIte = opts.MaxIte;        end
if isfield(opts, 'tol');         tol = opts.tol;              end

if isfield(opts, 'X0');          X0 = opts.X0;                end
if isfield(opts, 'Y0');          Y0 = opts.Y0;                end
if isfield(opts, 'E0');          E0 = opts.E0;                end
if isfield(opts, 'D0');          D0 = opts.D0;                end
if isfield(opts, 'C0');          C0 = opts.C0;                end

if isfield(opts, 'Omega');       Omega = opts.Omega;          end
if isfield(opts, 'dim');         dim = opts.dim;              end

if isfield(opts, 'lam2');         lam2 = opts.lam2 ;        end
if isfield(opts, 'r1');          r1 = opts.r1;        end
if isfield(opts, 'r2');          r2 = opts.r2;        end
if isfield(opts, 'r3');          r3 = opts.r3;        end


[n1 n2 n3] = size(M);

for k = 1:MaxIte  
    %% compute X^(k+1)
    
    AA=col2imstep(D0*C0, dim, [patchsize, patchsize, patchsize], [stepsize, stepsize, stepsize]);

    X1 = prox_DLmcpU(UU,X0 - (alpha2*(X0 - AA) + (X0 + E0 - M).* Omega)./ rho1, lam2, beta2./rho1, r1);

    %% compute E^(k+1)
   
    E1 = prox_mcp(E0 - ((X1 + E0).* Omega - M.* Omega)./rho2, lam2, gamma2./rho2, r2);  

    %% compute D^(k+1)
      
    [CU CS CV] = svd(C0*C0',0);

    rho3 = 1.5*alpha2*CS(1,1);
    
    patchData  = im2colstep(X1, [patchsize,patchsize,patchsize], [stepsize,stepsize,stepsize]);

    DA = (alpha2*(D0*C0 - patchData)*C0')./rho3;

    DA(find(isnan(DA)==1)) = 0;

    [DU, DS, DV] = svd(D0 - DA,0);   

    D1 = DU*DV';

    
    %% compute C^(k+1)

    C1 = prox_mcp(C0 - (alpha2*D1'*(D1*C0 - patchData))./rho4, lam2, lambda2./rho4, r3);   
      
    %% stopping criterion

   Rel = norm(X1(:) - X0(:))/norm(X0(:));
   if Rel  <= tol
       break; 
   end


    %% update variable
    X0 = X1;
    E0 = E1;
    C0 = C1;
    D0 = D1;
    
    
end
end
