function [L] = prox_DLmcpU(UU, T,lam,alp,r1)

% The proximal operator of the tensor nuclear norm of a 3 way tensor
%
% min_L alp*H(L)+0.5*||L-T||_F^2
%
% T     -    n1*n2*n3 tensor
%
% L     -    n1*n2*n3 tensor
% H(L)   -   �������� L����ֵ������
% tnn   -    tensor nuclear norm of L
% trank -    tensor tubal rank of L
%

% 

[n1,n2,n3] = size(T);
% L = zeros(n1,n2,n3);
% T = fft(T,[],3);

O = tenmat(T,[3]); %square norm
SS = O.data;
Y = UU'*SS;
Y = tensor(tenmat(Y, O.rdims, O.cdims, O.tsize));
T = Y.data;

tnn = 0;
trank = 0;

for i = 1 : n3
    [U,S,V] = svd(T(:,:,i),'econ');
    S = diag(S); % ȡ�Խ�Ԫ������µ�������S��Ԫ���ɴ�С�ţ�
    S = prox_mcp(S,lam,alp,r1);
    r = length(find(S~=0));
    S = S(1:r);
    L(:,:,i) = U(:,1:r)*diag(S)*V(:,1:r)';    

end
% L = ifft(L,[],3);

O = tenmat(L,[3]); %square norm
SS = O.data;
Y = UU*SS;
Y = tensor(tenmat(Y, O.rdims, O.cdims, O.tsize));
L = Y.data;

