function [x] = prox_mcp(b, c, lamda,eta)

% a = 3.7; 

%% proximal mapping of MCP

%%

x = b;
lam = c*lamda;   
i1 = find(lam<abs(b) & abs(b)<=eta*c);
x(i1) = (sign(b(i1)) .*(abs(b(i1))-lam))./(1-lamda/eta);

i2 = find(abs(b)<=lam);
x(i2) = 0;

end