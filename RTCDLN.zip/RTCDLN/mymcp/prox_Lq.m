function [x] = prox_Lq(b, q, yinte)

% The proximal operator of the g(x) yinte norm
% 
% min_x yinte*g(x)+0.5*��x-b��^2
%
% 
[n1 n2 n3] = size(b);
b = b(:);

 %% q=0 
if (q==0)
    x = b;
    i1 = find(abs(b)<=sqrt(2*yinte));
    x(i1) = 0;
 %% 0<q<1
elseif (q<1 && q>0)
    max_iter = 10;
    ABSTOL   = 1e-6;
    x    = zeros(length(b),1);
    beta = ( 1/ (yinte*2*(1-q)) )^(1/(q-2));%q=2
    f1   = yinte*q*beta.^(q-1) + beta - abs(b);
    i0   = find(f1<0);
    if ~isempty(i0) 
        b_u = abs(b(i0));
        x_u = b_u;
        for i=1:max_iter              
            deta_x = (yinte*q*x_u.^(q-1) + x_u - b_u) ./ (yinte*q*(q-1)*x_u.^(q-2) + 1);
            x_u    = x_u - deta_x;
            if ( norm(deta_x) < sqrt(length(x_u))*ABSTOL )
                break;
            end
        end
        x_u = x_u .* sign(b(i0));
        i1 = find(1/2 * b_u.^2 - yinte*abs(x_u).^q - 1/2*(x_u-b(i0)).^2 < 0);%x_u=0�ĺ���ֵ�� x_u����ֵ
        x_u(i1) = 0;
        x(i0) = x_u;
    end 
    %% q=1
elseif (q==1)
    x = sign(b) .* max(abs(b)-yinte, 0);
end

   x = reshape(x,[n1 n2 n3]);

end
