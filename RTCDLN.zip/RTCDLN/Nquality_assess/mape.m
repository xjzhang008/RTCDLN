function m = mape(YReal, YPred) %computes the mean absolute percentage error
    X = YReal - YPred;
    m = mean(abs(X./YReal));
end
