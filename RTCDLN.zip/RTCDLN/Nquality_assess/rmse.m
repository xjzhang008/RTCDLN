function r = rmse(YReal, YPred) %computes the residual mean square error
    X = YReal - YPred;
    r = sqrt(mean(X(:).^2));
end

