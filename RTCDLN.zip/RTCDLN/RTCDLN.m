%%
% code for the paper:
% Duo Qiu, Bei Yang, and Xiongjun Zhang. Robust Tensor Completion via Dictionary Learning and Generalized Nonconvex Regularization for Visual Data Recovery, 
% IEEE Transactions on Circuits and Systems for Video Technology, DOI: 10.1109/TCSVT.2024.3413992, 2024.
% If you have any question, please email to xjzhang@ccnu.edu.cn
%% Nonconvex + Dictionary Learning (Matrix)
clc
clear all

addpath('my data');
addpath('mymcp');
addpath('Nquality_assess');
addpath('Patch');
addpath('tensor_toolbox_2.6');
randn('seed',2013); 
randn('seed',2013);

%%  incomplete data


SR = 0.5;  %% sampling ratio \rho
SL = 0.1;  %% sparse impulse noise ratio
sigma = 0.05; %% Gaussian noise ratio

fprintf('Sampling ratio = %0.8e\n',SR);
fprintf('sparse corruption ratio = %0.8e\n',SL);
fprintf('Gaussian noise ratio = %0.8e\n',sigma);


load('fake_and_real_lemons')
fake_and_real_lemons = double(fake_and_real_lemons);
XT = fake_and_real_lemons./max(fake_and_real_lemons(:));
XT = imresize(XT,[256 256]);


%%

[n1, n2,n3] = size(XT);
dim = [n1, n2, n3];

STS = imnoise(XT,'salt & pepper',SL);
noise = STS + sigma*randn([n1,n2,n3]);



%% Set  Omega

temp=randperm(n1*n2*n3);
kks=round(SR*n1*n2*n3);
Omega=zeros(n1,n2,n3);
Omega(temp(1:kks))=1;
chosen=temp(1:kks);

M = noise.*Omega; %% observed tensor with missing entries
%% initial parameters

stepsize = 5;
patchsize = 5;

alpha = 1e-3;
lambda = 1e-4;



alpha2 = 1e-3;
lambda2 = 1e-4;
 
beta2 = 1.4;
laaaa = 7.5;
lam2 = 0.6;


beta = beta2;
lmmma = laaaa;
lam = lam2;

gamma = lmmma/sqrt(max(n1,n2)*n3*SR);
gamma2 = laaaa/sqrt(max(n1,n2)*n3*SR);

rho1 = 1.8*(alpha+1);
rho2 = 1.3;
rho4 = 1.2*alpha;

MaxIte = 300; 
tol = 1e-4;

rg = 50;

tr1 = rg*beta/rho1; % larger
tr2 = rg*gamma/rho2;
tr3 = rg*lambda/rho4;
tr4 = rg*lambda/alpha;

r1 = rg*beta2/rho1; % larger
r2 = rg*gamma2/rho2;
r3 = rg*lambda2/rho4;


%% Initialization of X^(0), Z^(0), E^(0), and y^(0)

X0 = zeros(dim);
E0 = zeros(dim); 

%% Initialization of C^(0) and D^(0)
patchData  = im2colstep(X0, [patchsize,patchsize,patchsize],[stepsize,stepsize,stepsize]);
D0 = DctInit(patchsize);
C0 = prox_mcp(D0'*patchData, lam, lambda./alpha, tr4);   


%% Initial point 
opts.stepsize= stepsize;
opts.patchsize= patchsize;
opts.alpha = alpha;
opts.beta = beta;
opts.lambda = lambda;
opts.gamma = gamma;

opts.alpha2 = alpha2;
opts.beta2 = beta2;
opts.lambda2 = lambda2;
opts.gamma2 = gamma2;  

opts.rho1 = rho1;
opts.rho2 = rho2;
opts.rho4 = rho4;

opts.MaxIte = MaxIte;
opts.tol = tol; 

opts.X0 = X0;         
opts.E0 = E0;
opts.D0 = D0;
opts.C0 = C0;
opts.Omega = Omega;          
opts.dim = dim;       

opts.tr1  = tr1;
opts.tr2  = tr2;
opts.tr3  = tr3;


opts.r1  = r1;
opts.r2  = r2;
opts.r3  = r3;

% opts.lam3  = lam3;
opts.lam2  = lam2;
opts.lam  = lam;

% %%  FFT
%   fprintf('===== t-SVD by Fast Fourier Transform =====\n');
%    tic
%      [X ,E, k ] = NDLMCPFFT(M,Omega,dim,opts);
%    toc
% 
% %% print the relative error, psnr
%      Error = norm(X(:)-XT(:))/norm(XT(:));
%     fprintf('Relative error = %0.8e\n',Error);
%     PSNR = psnr(XT(:),X(:));
%     fprintf('PSNR = %0.8e\n',PSNR);
%     SSIM = ssim3d(X*255,XT*255);
%     fprintf('SSIM = %0.8e\n',SSIM);


%%  DCT
  fprintf('===== t-SVD by Discrete Cosine Transform =====\n');
   tic
     [X E k] = RTCDLNDCT(M,Omega,dim,opts);
   toc

%% print the relative error, psnr
     Error = norm(X(:)-XT(:))/norm(XT(:));
    fprintf('Relative error = %0.8e\n',Error);
    PSNR = psnr(XT(:),X(:));
    fprintf('PSNR = %0.8e\n',PSNR);
    SSIM = ssim3d(X*255,XT*255);
    fprintf('SSIM = %0.8e\n',SSIM);

%% U Transform

 fprintf('===== t-SVD by unitary transform =====\n');

%% U matrix
O = tenmat(X,[3]); % unfolding
O = O.data;
[U S V] = svd(O,'econ');


  tic
    [XU E k] = RTCDLNU(U,M,Omega,dim,opts);
  toc

% print the relative error, psnr

    Error = norm(XU(:)-XT(:))/norm(XT(:));
    fprintf('Relative error = %0.8e\n',Error);
    PSNR = psnr(XT(:),XU(:));
    fprintf('PSNR = %0.8e\n',PSNR);
    SSIM = ssim3d(XU*255,XT*255);
    fprintf('SSIM = %0.8e\n',SSIM);
